# PulseCoreHorizontal_Power 横屏功耗主题

基于用户提供的 `PulseCoreHorizontal.zip`，保持 480×320 横屏卡片布局。

## 修改内容

- CPU 卡片第二行：原 `CpuFan` 改为 `CpuPower`。
- GPU 卡片第二行：原 `GpuFan` 改为 `GpuPower`。
- 两行的风扇图标改为白色闪电，单位 `RPM` 改为 `W`。
- 擦除框按原风扇图标的实际外沿取范围（图标上沿到行中心 15 像素、左右各外扩 4 像素），并关闭擦除填充的抗锯齿，避免残留旧图标顶部像素和蹭到卡片分隔线。
- 原风扇数值起点为 (190,52)/(190,207)，五字符。功耗采用三字符起点 (212,52)/(212,207)，每字符步进仍为11像素，因此数字区域右端与原转速一致。
- 字体、字号18、白色、行高、其它所有指标及布局保留。原本关闭的 CPU 功耗条目 (0,0) 仍关闭，没有额外功耗区域。
- 主题数据内的背景与随附 `Intel+Nvidia` 图片逐像素一致；随附图片及用户截图为 Ryzen，新主题仅在 CPU 标志局部裁入随附 Ryzen 图，GPU 保持 NVIDIA。

## 使用

已安装到 `release\35inch-3.5\config\PulseCoreHorizontal_Power.data`，在该目录下的功耗补丁版 `UsbMonitor.exe` 中选择 `PulseCoreHorizontal_Power`。

独立主题包 `release\PulseCoreHorizontal_Power.zip` 含主题 `.data`、预览和说明；如手工安装，将包内 `.data` 放入功耗补丁版软件的 `config` 目录，然后在软件中选择该主题。未替换原主题、未修改默认 `AppConfig.data`、未修改自启或运行中的软件。

**GPU 功耗需要之前交付的功耗补丁版程序。仅将主题装入未打补丁的官方原版不能建立 GPU 功耗绑定。**

## 验证

生成后经程序自己的主题序列化读写接口回读，核对数据绑定：CPU `x65`，GPU `180`。这是测试值，用于验证位置和绑定，并非实时测量。

原编辑器的逐字符预览将空位 `x` 替换成 `8`，因此其预览可把 `x65` 画成 `865`。交付的 PNG 使用单独的 `RuntimePreview`：先调用真实 `AdaptSensorData` 并保留日志，随后仅在预览对象中将 `x` 换为空格，再调用原绘图代码。主题和运行程序没有被此预览处理修改。

像素比较验证：背景变化仅在两行单位/图标及 Ryzen 标志区域，其它背景像素不变；原空白 `osdImg` 保持不变。逐项结构比较验证：除两项的绑定、中文名称、数字起点和字符宽度外，其它传感器字段和字体没有变化。

尚未目视验收实体副屏的显示效果。功耗以原程序整数格式显示，例如 65 W、180 W。

## 可复用生成器

`tools\theme\power\ThemePowerGenH.cs` 是竖屏生成器 `ThemePowerGen.cs` 的横屏姊妹版，接受原主题、Ryzen 图片、输出主题、背景预览路径四个参数，默认输入取自 `tools\theme\power\in_h`，不依赖临时目录作为唯一来源。`VerifyPixelsH.cs` / `VerifyBindingsH.cs` 是横屏专用校验器。`RuntimePreview.cs` 是独立预览工具，不改动既有 `Preview.cs`。
